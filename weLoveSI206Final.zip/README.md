# 206final

Project that uses the Merriam Webster API, and the Yelp API to compare users numerical rating
to an "emotion rating"

Run the file with the command --help to receive detailed usage instructions
